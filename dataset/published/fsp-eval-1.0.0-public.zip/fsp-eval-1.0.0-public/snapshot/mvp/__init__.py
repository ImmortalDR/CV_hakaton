# Pure MVP snapshot; no API/database.
