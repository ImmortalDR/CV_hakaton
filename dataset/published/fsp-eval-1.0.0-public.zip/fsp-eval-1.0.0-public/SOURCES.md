# Источники

Права на код и документы источников различаются. Локальный доступ не является разрешением публиковать реальные профили.

| ID | Источник | Версия | Лицензия / статус |
|---|---|---|---|
| team_synthetic | [ФСП: контрольные сценарии команды](https://github.com/ImmortalDR/CV_hakaton/tree/codex/fsp-mvp/dataset) | 1.0.0 | MIT; allowed |
| mvp | [Проверяемая реализация MVP и независимые решатели](https://github.com/ImmortalDR/CV_hakaton/tree/codex/fsp-mvp) | snapshot hashes in manifest | MIT; allowed |
| trudvsem | [Работа в России / ИНИД](https://data.rcsi.science/data-catalog/datasets/186/) | 2021-12-02 | CC-BY-SA-4.0; local_only_pending_privacy_review |
| tianchi | [Tianchi / Zhaopin 44080](https://tianchi.aliyun.com/dataset/44080) | user-supplied files; SHA-256 pinned | не установлена; local_only_terms_unverified |
| confit | [ConFit (RecSys 2024)](https://github.com/jasonyux/ConFit) | user-supplied ConFit-master.zip; SHA-256 pinned | не установлена; local_only_terms_unverified |
| talentclef | [TalentCLEF 2025](https://zenodo.org/records/15038364) | 0.3.0 | не установлена; local_only_terms_unverified |
| careercorpus | [CareerCorpus](https://data.mendeley.com/datasets/wzzwn37gmd/1) | 1 | CC-BY-4.0; local_only_pending_privacy_review |

Tianchi: страница доступна как JS-приложение; условия NC/SA из старого описания не подменяют проверку точной лицензии. ConFit содержит заглушки текстов; они не используются как документы. TalentCLEF: в предоставленных архивах test/ пуст. CareerCorpus: оценки исходных авторов не являются нашей разметкой или подтверждением Python/Data-грейда.
